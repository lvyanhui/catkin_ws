#include "ros/ros.h"
#include "std_msgs/String.h"
#include "start/Rect.h"
#include "start/Object.h"
#include "start/ObjectVec.h"

#include <sstream>

int main(int argc, char **argv)
{
  ros::init(argc,argv,"talker");
  ros::NodeHandle n;

  //ros::Publisher chatter_pub = n.advertise<std_msgs::String>("chatter", 1000);
  ros::Publisher chatter_pub = n.advertise<start::ObjectVec>("chatter", 1000);

  ros::Rate loop_rate(10);

  int count = 0;
  while (ros::ok())
  {
    
    /*std_msgs::String msg;

    std::stringstream ss;
    ss << "hello world " << count;
    msg.data = ss.str();

    ROS_INFO("%s", msg.data.c_str());
    */
    
    start::ObjectVec msg;
    start::Object obj;
    
    obj.classid = count;
    obj.confidence = 0.9;
    obj.rect.top = 50;
    obj.rect.left = 50;
    obj.rect.width = 100;
    obj.rect.height = 100;
    msg.objects.push_back(obj);

    obj.classid = count*100;
    obj.confidence = 0.9;
    obj.rect.top = 40;
    obj.rect.left = 40;
    obj.rect.width = 100;
    obj.rect.height = 100;
    msg.objects.push_back(obj);
    
    ROS_INFO("%d, %d", msg.objects[0].classid, msg.objects[1].classid);

    chatter_pub.publish(msg);

    ros::spinOnce();

    loop_rate.sleep();

    ++count;
  }
  
  return 0;
}
